package com.imooc.menu;

public class ClickButton extends Button{
	//Click���Ͳ˵�key
	private String key;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
}
