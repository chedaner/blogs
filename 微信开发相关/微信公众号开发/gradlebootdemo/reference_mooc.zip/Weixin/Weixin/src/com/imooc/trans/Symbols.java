package com.imooc.trans;

public class Symbols {
	private String ph_am;
	private String ph_en;
	private String ph_zh;
	private Parts[] parts;
	public String getPh_am() {
		return ph_am;
	}
	public void setPh_am(String ph_am) {
		this.ph_am = ph_am;
	}
	public String getPh_en() {
		return ph_en;
	}
	public void setPh_en(String ph_en) {
		this.ph_en = ph_en;
	}
	public String getPh_zh() {
		return ph_zh;
	}
	public void setPh_zh(String ph_zh) {
		this.ph_zh = ph_zh;
	}
	public Parts[] getParts() {
		return parts;
	}
	public void setParts(Parts[] parts) {
		this.parts = parts;
	}
}
