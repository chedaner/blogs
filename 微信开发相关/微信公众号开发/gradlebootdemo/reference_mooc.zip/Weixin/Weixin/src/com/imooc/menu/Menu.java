package com.imooc.menu;

public class Menu {
	//һ���˵�
	private Button[] button;

	public Button[] getButton() {
		return button;
	}

	public void setButton(Button[] button) {
		this.button = button;
	}
}
