package com.imooc.trans;

public class Data {
	private String word_name;
	private Symbols[] symbols;
	public String getWord_name() {
		return word_name;
	}
	public void setWord_name(String word_name) {
		this.word_name = word_name;
	}
	public Symbols[] getSymbols() {
		return symbols;
	}
	public void setSymbols(Symbols[] symbols) {
		this.symbols = symbols;
	}
}
